g++ -std=c++11 Itsy_bitsy_spider.cpp -o maze
./maze